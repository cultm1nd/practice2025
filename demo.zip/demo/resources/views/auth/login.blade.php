@extends('layouts.header')
@section('content')
<form method="POST" action="{{route('login')}}">
    @csrf
    <h1>Авторизация</h1>
    <div class="mb-3">
    <label for="login" class="form-label">Логин</label>
   <input type="text" class="form-control" id="login" name="login" required>
   </div>

     <div class="mb-3">
     <label for="password" class="form-label">Пароль (минимум 6 символов)</label>
     <input type="password" class="form-control" id="password" name="password" required>
    </div>
  <button type="submit" class="btn btn-primary">Войти</button>
</form>
<br>
<a href="{{ url()->previous() }}" class="btn btn-secondary">Назад</a>
@endsection