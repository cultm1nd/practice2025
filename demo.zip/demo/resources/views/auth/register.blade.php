@extends('layouts.header')
@section('content')
<form method="POST" action="{{route('register')}}">
    @csrf
    <h1>Регистрация</h1>
  <div class="mb-3">
    <label for="surname" class="form-label">Фамилия</label>
    <input type="text" class="form-control" id="surname" name="surname" required>
  </div>

  <div class="mb-3">
    <label for="name" class="form-label">Имя</label>
    <input type="text" class="form-control" id="name" name="name" required>
  </div>

  <div class="mb-3">
    <label for="secondname" class="form-label">Отчество</label>
    <input type="text" class="form-control" id="secondname" name="secondname" required>
  </div>

  <div class="mb-3">
    <label for="Телефон" class="form-label">Телефон</label>
    <input type="text" class="form-control" id="phone" name="phone" placeholder="+7(XXX)-XXX-XX-XX" required>
  </div>

  <div class="mb-3">
     <label for="address" class="form-label">Адрес</label>
     <input type="text" class="form-control" id="address" name="address" required>
      </div>

  <div class="mb-3">
   <label for="email" class="form-label">Email</label>
   <input type="email" class="form-control" id="email" name="email" required>
    </div>

    <div class="mb-3">
    <label for="login" class="form-label">Логин</label>
   <input type="text" class="form-control" id="login" name="login" required>
   </div>

     <div class="mb-3">
     <label for="password" class="form-label">Пароль (минимум 6 символов)</label>
     <input type="password" class="form-control" id="password" name="password" required>
    </div>

    

  <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
  
  
</form>
<br>
<a href="{{ url()->previous() }}" class="btn btn-secondary">Назад</a>
<script>
        // Маска для телефона
        document.getElementById('phone').addEventListener('input', function (e) {
            let x = e.target.value.replace(/\D/g, '').match(/(\d{0,1})(\d{0,3})(\d{0,3})(\d{0,2})(\d{0,2})/);
            e.target.value = !x[2] ? x[1] : x[1] + '(' + x[2] + ')' + (x[3] ? '-' + x[3] : '') + (x[4] ? '-' + x[4] : '') + (x[5] ? '-' + x[5] : '');
        });
    </script>
@endsection