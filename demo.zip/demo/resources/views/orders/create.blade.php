@extends('layouts.header')
@section('content')
<div class="container">
    <h2 class="mb-4">Новая заявка</h2>

    <form method="POST" action="{{ route('orders.store') }}">
        @csrf
        <div class="mb-3">
            <label class="form-label">Услуга</label>
            <select name="id_service" class="form-select" required>
                @foreach($services as $service)
                <option value="{{ $service->id }}">{{ $service->title }}</option>
                @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Адрес</label>
            <input type="text" name="address" value="{{ auth()->user()->address }}" class="form-control" required>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Дата</label>
                <input type="date" name="date" class="form-control" min="{{ date('Y-m-d') }}" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Время</label>
                <input type="time" name="time" class="form-control" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Оплата</label>
            <select name="payment_type" class="form-select" required>
                <option value="cash">Наличные</option>
                <option value="card">Карта</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Комментарий</label>
            <textarea name="desc" class="form-control" rows="2"></textarea>
        </div>

        <button type="submit" class="btn btn-primary w-100">Создать заявку</button>
    </form>
</div>
@endsection