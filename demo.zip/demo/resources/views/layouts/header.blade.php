<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
  <!-- <link rel="stylesheet" href="./styles/bootstrap.min.css"> -->
</head>

<body>

  <div class="container">
    <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
      <div class="col-md-3 mb-2 mb-md-0">
        <h1>МОЙ НЕ САМ</h1>
      </div>

      <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
        @auth
        <li><a href="{{route('orders.index')}}" class="nav-link px-2 link-secondary">Мои заявки</a></li>
        @if(Auth::user()->isAdmin())
        <li><a href="{{route('admin.index')}}" class="nav-link px-2">Все заявки</a></li>
        @endif
        @endauth
      </ul>

      @auth
      <div class="col-md-3 text-end">
        <form action="{{ route('logout') }}" method="POST">
          @csrf
          <button type="submit" class="btn btn-primary">Выход</button>
        </form>
      </div>
      @endauth
    </header>

    @yield('content')

    <div class="container">
      <footer class="py-3 my-4">
        <p class="text-center text-body-secondary">© 2025 Мой не сам</p>
      </footer>
    </div>
  </div>


  <script src="./jquery/jquery-3.3.3.js"></script>
  <script src="./js/bootstrap.min.js"></script>
</body>

</html>