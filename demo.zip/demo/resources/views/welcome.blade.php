@extends('layouts.header')
@section('content')
<div class="card">
<div class="card-body">
    <h1 class="card-title">Добро пожаловать в МОЙ НЕ САМ</h1>
    <p class="card-text">Предоставляем услуги клининга</p>
    @auth
    <a href="{{route('orders.create')}}" class="btn btn-primary">Создать заявку</a>
    @else
    <div clas="d-flex gap-2">
        <a href="{{route('register')}}" class="btn btn-primary">Регистрация</a>
        <a href="{{route('login')}}" class="btn btn-success">Войти</a>
    </div>
    @endauth
</div>
</div>
@endsection