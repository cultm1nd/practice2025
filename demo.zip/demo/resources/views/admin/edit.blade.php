@extends('layouts.header')
@section('content')
<div class="container mt-4">
    <h2>Редактирование заказа #{{ $order->id }}</h2>
    
    <form method="POST" action="{{ route('admin.orders.update', $order->id) }}">
        @csrf
        @method('PUT')
        
        <div class="mb-3">
            <label for="service_id" class="form-label">Услуга</label>
            <select class="form-select" id="service_id" name="service_id" required>
                @foreach($services as $service)
                    <option value="{{ $service->id }}" {{ $order->service_id == $service->id ? 'selected' : '' }}>
                        {{ $service->title }}
                    </option>
                @endforeach
            </select>
        </div>
        
        <div class="mb-3">
            <label for="date" class="form-label">Дата</label>
            <input type="date" class="form-control" id="date" name="date" value="{{ $order->date }}" required>
        </div>
        
        <div class="mb-3">
            <label for="time" class="form-label">Время</label>
            <input type="time" class="form-control" id="time" name="time" value="{{ $order->time }}" required>
        </div>
        
        <div class="mb-3">
            <label for="id_status" class="form-label">Статус</label>
            <select class="form-select" id="id_status" name="id_status" required>
                @foreach($statuses as $status)
                    <option value="{{ $status->id }}" {{ $order->id_status == $status->id ? 'selected' : '' }}>
                        {{ $status->title }}
                    </option>
                @endforeach
            </select>
        </div>
        
        <div class="mb-3">
            <label for="desc" class="form-label">Комментарий</label>
            <textarea class="form-control" id="desc" name="desc" rows="3">{{ $order->desc }}</textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Сохранить</button>
        <a href="{{ route('admin.index') }}" class="btn btn-secondary">Отмена</a>
    </form>
</div>
@endsection