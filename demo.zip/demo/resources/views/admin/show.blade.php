@extends('layouts.header')
@section('content')
<div class="container mt-4">
    <h2>Детали заказа #{{ $order->id }}</h2>
    
    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Информация о клиенте</h5>
            <p><strong>ФИО:</strong> {{ $order->user->surname }} {{ $order->user->name }} {{ $order->user->secondname }}</p>
            <p><strong>Телефон:</strong> {{ $order->user->phone }}</p>
            <p><strong>Email:</strong> {{ $order->user->email }}</p>
            <p><strong>Адрес:</strong> {{ $order->user->address }}</p>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title">Информация о заказе</h5>
            <p><strong>Услуга:</strong> {{ $order->service->title }}</p>
            <p><strong>Дата и время:</strong> {{ $order->date }} {{ $order->time }}</p>
            <p><strong>Статус:</strong> {{ $order->status->title ?? 'Не указан' }}</p>
            @if($order->desc)
                <p><strong>Комментарий:</strong> {{ $order->desc }}</p>
            @endif
        </div>
    </div>

    <div class="mt-3">
        <a href="{{ route('admin.index') }}" class="btn btn-secondary">Назад</a>
        <a href="{{ route('admin.orders.edit', $order->id) }}" class="btn btn-primary">Редактировать</a>
    </div>
</div>
@endsection