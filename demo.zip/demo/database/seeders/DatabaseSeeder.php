<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // \App\Models\User::factory(10)->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
        User::create([
            'surname' => 'Admin',
            'name' => 'Admin',
            'secondname' => 'Admin',
            'phone' => '+7(999)999-99-99',
            'email' => 'admin@example.com',
            'login' => 'adminka',
            'password' => Hash::make('password'),
            'address' => 'Admin address',
            'id_role' => 1, // Администратор
        ]);
    }
}
