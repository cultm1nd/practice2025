
<?php $__env->startSection('content'); ?>
<div class="card">
<div class="card-body">
    <h1 class="card-title">Добро пожаловать в МОЙ НЕ САМ</h1>
    <p class="card-text">Предоставляем услуги клининга</p>
    <?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">Создать заявку</a>
    <?php else: ?>
    <div clas="d-flex gap-2">
        <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">Регистрация</a>
        <a href="<?php echo e(route('login')); ?>" class="btn btn-success">Войти</a>
    </div>
    <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\demo\resources\views/welcome.blade.php ENDPATH**/ ?>