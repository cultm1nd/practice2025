

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="mb-0">Мои заявки</h2>
        <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Новая заявка
        </a>
    </div>

    <?php if($orders->isEmpty()): ?>
        <div class="alert alert-info text-center">
            <i class="fas fa-info-circle"></i> У вас пока нет заявок
        </div>
    <?php else: ?>
        <div class="row g-3">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title mb-0 text-primary">
                                <?php echo e($order->service->title); ?>

                            </h5>
                            <span class="badge rounded-pill 
                                <?php if($order->status === 'done'): ?> bg-success
                                <?php elseif($order->status === 'in work'): ?> bg-primary
                                <?php else: ?> bg-secondary
                                <?php endif; ?>">
                                <?php if($order->status === 'done'): ?> 
                                    <i class="fas fa-check"></i> Выполнено
                                <?php elseif($order->status === 'in work'): ?> 
                                <i class="fas fa-times"></i> Отменено
                                  
                                <?php else: ?> 
                                <i class="fas fa-spinner"></i> В работе 
                                <?php endif; ?>
                            </span>
                        </div>
                        
                        <div class="card-details mt-3">
                            <div class="mb-2">
                                <i class="far fa-calendar-alt text-muted"></i>
                                <span class="ms-2"><?php echo e($order->date); ?></span>
                            </div>
                            <div class="mb-2">
                                <i class="far fa-clock text-muted"></i>
                                <span class="ms-2"><?php echo e($order->time); ?></span>
                            </div>
                            <div>
                                <i class="fas fa-map-marker-alt text-muted"></i>
                                <span class="ms-2"><?php echo e($order->address); ?></span>
                            </div>
                        </div>

                        <?php if($order->status === 'cancel' && $order->desc): ?>
                            <div class="alert alert-light mt-3 mb-0 p-2 small">
                                <i class="fas fa-exclamation-circle text-danger"></i>
                                <?php echo e($order->desc); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\demo\resources\views/orders/index.blade.php ENDPATH**/ ?>