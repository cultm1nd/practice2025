
<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo csrf_field(); ?>
    <h1>Авторизация</h1>
    <div class="mb-3">
    <label for="login" class="form-label">Логин</label>
   <input type="text" class="form-control" id="login" name="login" required>
   </div>

     <div class="mb-3">
     <label for="password" class="form-label">Пароль (минимум 6 символов)</label>
     <input type="password" class="form-control" id="password" name="password" required>
    </div>
  <button type="submit" class="btn btn-primary">Войти</button>
</form>
<br>
<a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Назад</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\demo\resources\views/auth/login.blade.php ENDPATH**/ ?>