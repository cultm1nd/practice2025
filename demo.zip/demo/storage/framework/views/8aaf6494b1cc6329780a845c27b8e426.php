
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Новая заявка</h2>

    <form method="POST" action="<?php echo e(route('orders.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Услуга</label>
            <select name="id_service" class="form-select" required>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($service->id); ?>"><?php echo e($service->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Адрес</label>
            <input type="text" name="address" value="<?php echo e(auth()->user()->address); ?>" class="form-control" required>
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Дата</label>
                <input type="date" name="date" class="form-control" min="<?php echo e(date('Y-m-d')); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Время</label>
                <input type="time" name="time" class="form-control" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Оплата</label>
            <select name="payment_type" class="form-select" required>
                <option value="cash">Наличные</option>
                <option value="card">Карта</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Комментарий</label>
            <textarea name="desc" class="form-control" rows="2"></textarea>
        </div>

        <button type="submit" class="btn btn-primary w-100">Создать заявку</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\demo\resources\views/orders/create.blade.php ENDPATH**/ ?>