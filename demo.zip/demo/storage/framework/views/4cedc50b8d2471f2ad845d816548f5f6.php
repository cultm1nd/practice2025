
<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Панель администратора</h2>

    <div class="table-responsive mt-3">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Клиент</th>
                    <th>Услуга</th>
                    <th>Дата</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td><?php echo e($order->user->surname); ?> <?php echo e($order->user->name); ?></td>
                    <td><?php echo e($order->service->title); ?></td>
                    <td><?php echo e($order->date); ?> <?php echo e($order->time); ?></td>
                    <td><?php if($order->status != null): ?>
                        <?php echo e($order->status->title); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="POST" action="<?php echo e(route('admin.update-status', $order->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <select name="status_id" class="form-select form-select-sm">
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status->id); ?>" <?php echo e($order->id_status == $status->id ? 'selected' : ''); ?>>
                                    <?php echo e($status->title); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($order->id_status == 3): ?>
                            <input type="text" name="cancel_reason" value="<?php echo e($order->desc); ?>" class="form-control form-control-sm mt-1" placeholder="Причина отмены">
                            <?php endif; ?>
                            <button type="submit" class="btn btn-sm btn-primary mt-1">Сохранить</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\borovinskikh\demo\resources\views/admin/index.blade.php ENDPATH**/ ?>