<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
    protected $fillable = [
        'date',
        'time',
        'payment_type',
        'desc',
        'id_user',
        'id_service',
        'id_status',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user');
    }

    public function service()
    {
        return $this->belongsTo(Service::class, 'id_service');
    }

    public function status()
    {
        return $this->belongsTo(Status::class, 'id_status');
    }
}
