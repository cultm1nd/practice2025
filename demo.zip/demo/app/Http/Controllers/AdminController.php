<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Role;
use App\Models\Service;
use App\Models\Status;
use App\Models\Order;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        if (auth()->user()->id_role !== 1) {
            return redirect('/');
        }

        $orders = Order::with(['user', 'service', 'status'])->latest()->get();
        $statuses = Status::all();

        return view('admin.index', compact('orders', 'statuses'));
    }

    public function show(Order $order)
    {
        if (auth()->user()->id_role !== 1) {
            return back()->with('error', 'Доступ запрещен');
        }

        return view('admin.orders.show', compact('order'));
    }

    public function edit(Order $order)
    {
        if (auth()->user()->id_role !== 1) {
            return back()->with('error', 'Доступ запрещен');
        }

        $services = Service::all();
        $statuses = Status::all();
        
        return view('admin.orders.edit', compact('order', 'services', 'statuses'));
    }

    public function update(Request $request, Order $order)
    {
        if (auth()->user()->id_role !== 1) {
            return back()->with('error', 'Доступ запрещен');
        }

        $validated = $request->validate([
            'service_id' => 'required|exists:services,id',
            'date' => 'required|date',
            'time' => 'required',
            'id_status' => 'required|exists:statuses,id',
            'desc' => 'nullable|string'
        ]);

        $order->update($validated);

        return redirect()->route('admin.index')->with('success', 'Заказ успешно обновлен');
    }

    public function destroy(Order $order)
    {
        if (auth()->user()->id_role !== 1) {
            return back()->with('error', 'Доступ запрещен');
        }

        $order->delete();

        return redirect()->route('admin.index')->with('success', 'Заказ успешно удален');
    }

    public function updateStatus(Request $request, $orderId)
    {
        if (auth()->user()->id_role !== 1) {
            return back()->with('error', 'Доступ запрещен');
        }

        $order = Order::findOrFail($orderId);

        $order->update([
            'id_status' => $request->status_id,
            'desc' => $request->status_id == 3 ? $request->cancel_reason : null
        ]);

        return back()->with('success', 'Статус обновлен');
    }
}