<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Role;
use App\Models\Service;
use App\Models\Status;
use App\Models\Order;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {

        if (auth()->user()->id_role !== 1) {
            return redirect('/');
        }

        $orders = Order::with(['user', 'service', 'status'])->latest()->get();
        $statuses = Status::all();

        return view('admin.index', compact('orders', 'statuses'));
    }

    public function updateStatus(Request $request, $orderId)
    {
        if (auth()->user()->id_role !== 1) {
            return back()->with('error', 'Доступ запрещен');
        }

        $order = Order::findOrFail($orderId);

        $order->update([
            'id_status' => $request->status_id,
            'desc' => $request->status_id == 3 ? $request->cancel_reason : null
        ]);

        return back()->with('success', 'Статус обновлен');
    }
}
