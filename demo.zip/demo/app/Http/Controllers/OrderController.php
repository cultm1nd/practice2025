<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Order;
use App\Models\Service;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index()
    {
        $orders = auth()->user()->orders()
            ->with('service')
            ->latest()
            ->get();
        
        return view('orders.index', compact('orders'));
    }

    public function create()
    {
        $services = Service::all();
        return view('orders.create', compact('services'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_service' => 'required|exists:services,id',
            'address' => 'required|string|max:255',
            'date' => 'required|date|after:today',
            'time' => 'required',
            'payment_type' => 'required|in:cash,card',
            'desc' => 'nullable|string|max:500',
        ]);

        Order::create([
            'id_user' => auth()->id(),
            'id_service' => $data['id_service'],
            'address' => $data['address'],
            'date' => $data['date'],
            'time' => $data['time'],
            'payment_type' => $data['payment_type'],
            'desc' => $data['desc'],
            'id_status' => 2, //статус в работе
        ]);

        return redirect()->route('orders.index')->with('success', 'Заявка создана!');
    }
}