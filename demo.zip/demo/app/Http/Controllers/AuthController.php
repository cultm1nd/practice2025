<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\User;

class AuthController extends Controller
{
    public function showLoginForm(){
        return view('auth.login');
    }
    public function login(Request $request){
        if(Auth::attempt($request->only('login', 'password'))){
            $request->session()->regenerate();
            return redirect()->intended('/orders');
        }
        return back()->with('error', 'неверный логин или пароль');
    }

    public function showRegisterForm(){
        return view('auth.register');
    }
    public function register(Request $request){
        //валидация
     $data= $request->validate([
     'surname'=>'required|string|max:255',
     'name'=>'required|string|max:255',
     'secondname'=>'required|string|max:255',
     'phone'=>'required|string|max:20',
     'email'=>'required|email|unique:users',
     'login'=>'required|unique:users',
     'password'=>'required|min:6',
     'address'=>'required|string',
     ]);
     //создание пользователя
     $user= User::create([
      'surname'=> $data['surname'],
      'name'=> $data['name'],
      'secondname'=> $data['secondname'],
      'phone'=> $data['phone'],
      'address'=> $data['address'],
      'email'=> $data['email'],
      'login'=> $data['login'],
      'password'=> Hash::make($data['password']),
      'id_role'=>2,

     ]);
     Auth::login($user);
     return redirect('/orders');
    }

    public function logout(){
        Auth::logout();
        return redirect('/');

    }
    
}
